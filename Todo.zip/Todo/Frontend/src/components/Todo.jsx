import React, { useEffect, useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Toolbar from '@mui/material/Toolbar'
import axios from 'axios';
import { AppBar, Box, Button, Checkbox, Typography} from '@mui/material';


const Todo = () => {

 const [rows,setRows]=useState([])

  const handleToggle = (id) => {
    setRows(prevRows => 
      prevRows.map(row => 
        row.id === id ? { ...row, completed: !row.completed } : row
      )
    );
  };

  

  return (
     <>

  <nav className='nav'>
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            TODO
          </Typography>
          <Button color="inherit">Add</Button>
        </Toolbar>
      </AppBar>
    </Box>
    </nav>


    <TableContainer component={Paper}>
    <Table sx={{ minWidth: 650 }} aria-label="employee table">
      <TableHead >
        <TableRow >
          <TableCell align="center" style={{ fontWeight: 'bold' }}>ID</TableCell>
          <TableCell align="center" style={{ fontWeight: 'bold' }}>DESCRIPTION</TableCell>
          <TableCell align="center" style={{ fontWeight: 'bold' }}>COMPLETED</TableCell>
        </TableRow>
      </TableHead>

      <TableBody>
        {rows.map((row) => (
          <TableRow key={row.id} className="tableRow">
            <TableCell align="center">{row.id}</TableCell>
            <TableCell align="center">{row.description}</TableCell>
            <TableCell align="center">                
                <Checkbox
                  checked={row.completed}
                  onChange={() => handleToggle(row.id)}
                  color="primary"
                />
                </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  </TableContainer>



  </> 
  )
}

export default Todo