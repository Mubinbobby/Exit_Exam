import React from 'react'

export const Add = () => {
  return (
    <div>Add</div>
  )
}

export default Add