import { useState } from 'react'
import './App.css'
import { Route, Routes } from 'react-router-dom'
import { Add } from './components/Add'
import Todo from './components/Todo'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Routes>
      <Route path='/' element={<Todo/>}/>
      <Route path='/add' element={<Add/>}/>
    </Routes>
      
    </>
  )
}

export default App